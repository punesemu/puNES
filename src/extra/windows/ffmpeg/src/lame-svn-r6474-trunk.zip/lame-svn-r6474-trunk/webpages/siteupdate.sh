#!/bin/sh

umask 002
svn update $*
